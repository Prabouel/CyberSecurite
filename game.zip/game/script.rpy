# -*- coding: utf-8 -*-
# TA SÉCURITÉ NUMÉRIQUE COMMENCE ICI ! — mini-jeu pour le collège
# Installation : créer un projet Ren'Py (1280 x 720 conseillé), puis remplacer
# game/ par le dossier game/ de cette archive (script, image et sons inclus).
# Projet existant : conserver le nom cybersecurite.rpy, éviter un second label
# start, et retirer le label start ci-dessous. Appeler : call cyber_mission
# Durée indicative : 10 à 15 minutes + échanges en classe.
# Les questions et corrections se modifient dans CYBER_QUESTIONS ci-dessous.
# Source d'inspiration : Réseau Canopé, « Améliorer la cybersécurité de ses
# outils numériques », février 2023, https://tube.reseau-canope.fr/w/2C9ZLEhnHfFLjpz82h8aTH
# Adaptation pédagogique originale fondée sur les éléments visuels du fichier.
# Pas de reprise des médias Canopé. Décor et sons repris du projet fourni par l’enseignant.
# Aide à la rédaction et au code : OpenAI ChatGPT, septembre 2026.
# Aucun nom, mot de passe réel ou donnée personnelle demandé ; aucun envoi réseau.
# Proposition de licence pour ce code et ces textes originaux : CC BY-NC-SA 4.0.
# Cette proposition ne modifie pas les droits de la vidéo source (CC BY-NC-ND 4.0).
# Ren'Py : https://www.renpy.org/ — moteur sous ses propres licences.
# Débrief : demander aux élèves de justifier un choix et de citer un réflexe.

define CYBER_QUESTIONS = [{'title': 'Le compte du club', 'prompt': 'Tu crées un compte pour le club du collège. Quel mot de passe choisis-tu ?', 'choices': ['Le nom du collège suivi de mon année de naissance.', 'Une longue phrase de passe imprévisible, réservée à ce compte.', 'Le même mot de passe que pour tous mes autres comptes.', 'Un mot très court avec un point d’exclamation.'], 'correct': 1, 'feedback': 'Un mot de passe doit être long, difficile à deviner et différent pour chaque compte. Évite les informations personnelles. Les exemples de ce jeu ne sont pas des mots de passe à réutiliser.', 'skill': 'Mots de passe'}, {'title': 'Trop de mots de passe !', 'prompt': 'Tu as plusieurs comptes et tu oublies leurs mots de passe. Quelle solution privilégies-tu ?', 'choices': ['Un document partagé avec toute la classe.', 'Un message envoyé à mes amis.', 'Un gestionnaire de mots de passe fiable, comme KeePass, avec un mot de passe principal solide.', 'Une photo de tous mes mots de passe conservée dans un album partagé.'], 'correct': 2, 'feedback': 'Un gestionnaire conserve les mots de passe dans un coffre chiffré. Il faut protéger son accès et suivre les consignes de ton établissement. Ne partage jamais tes mots de passe.', 'skill': 'Gestionnaire de mots de passe'}, {'title': 'La sonnerie retentit', 'prompt': 'Tu quittes momentanément un ordinateur du collège alors que ta session est ouverte. Que fais-tu ?', 'choices': ['Je verrouille ma session ; à la fin du travail, je me déconnecte.', 'Je ferme seulement la page affichée.', 'Je laisse la session ouverte pour le prochain élève.', 'Je réduis toutes les fenêtres : personne ne verra mes documents.'], 'correct': 0, 'feedback': 'Verrouiller empêche une autre personne d’utiliser ta session pendant ton absence. Sur un ordinateur partagé, déconnecte-toi à la fin : fermer une page ne suffit pas toujours.', 'skill': 'Session'}, {'title': 'Le message urgent', 'prompt': 'Un message annonce : « Ton compte sera supprimé ! Clique ici et donne ton mot de passe. » Quelle est ta première réaction ?', 'choices': ['Je réponds avec mon mot de passe.', 'Je vérifie par un autre moyen, en passant par le site habituel ou un adulte.', 'Je clique vite puisque le message est urgent.', 'Je le transfère à toute la classe en demandant de cliquer pour vérifier.'], 'correct': 1, 'feedback': 'L’urgence peut servir à te faire agir sans réfléchir : c’est un signe possible d’hameçonnage. Ne transmets pas ton mot de passe. Accède au service par son adresse habituelle et demande de l’aide.', 'skill': 'Hameçonnage'}, {'title': 'Le cadenas du navigateur', 'prompt': 'Un site affiche HTTPS et un cadenas. Que peux-tu en déduire ?', 'choices': ['Le site est forcément honnête.', 'Tous ses téléchargements sont sans danger.', 'La connexion est chiffrée, mais je dois encore vérifier le site et son adresse.', 'Le cadenas signifie que le site appartient à un organisme officiel.'], 'correct': 2, 'feedback': 'HTTPS protège les échanges pendant leur transport. Un site frauduleux peut aussi utiliser HTTPS : le cadenas ne garantit ni son honnêteté ni la sécurité de ses fichiers.', 'skill': 'HTTPS'}, {'title': 'Une mise à jour apparaît', 'prompt': 'L’ordinateur propose une mise à jour de sécurité. Quelle bonne habitude adoptes-tu ?', 'choices': ['Sur mon appareil, je passe par les réglages officiels ; au collège, je préviens le responsable si nécessaire.', 'Je désactive définitivement les mises à jour.', 'Je télécharge un correctif depuis une publicité inconnue.', 'Je reporte toujours la mise à jour tant que l’ordinateur fonctionne.'], 'correct': 0, 'feedback': 'Les mises à jour corrigent notamment des failles de sécurité. Utilise les sources officielles. Sur un appareil du collège, respecte les droits d’accès et demande à la personne responsable.', 'skill': 'Mises à jour'}, {'title': 'Le devoir irremplaçable', 'prompt': 'Ton exposé est enregistré uniquement sur ton ordinateur. Comment éviter de tout perdre ?', 'choices': ['Je renomme le fichier.', 'Je fais une copie sur un autre support ou un espace autorisé, puis je vérifie que je peux la récupérer.', 'Je crée un raccourci sur le bureau.', 'Je copie le fichier dans un autre dossier du même disque et je compte uniquement sur cette copie.'], 'correct': 1, 'feedback': 'Une sauvegarde est une copie que tu peux restaurer. Une copie sur le même disque ne protège pas contre sa panne. Utilise un support ou un service autorisé et ne sauvegarde pas inutilement les données des autres.', 'skill': 'Sauvegardes'}, {'title': 'Le Wi-Fi de la gare', 'prompt': 'Tu es connecté à un Wi-Fi public et tu veux ouvrir un compte important. Que privilégies-tu ?', 'choices': ['Je considère tout Wi-Fi gratuit comme fiable.', 'Je désactive les protections du navigateur.', 'J’attends une connexion de confiance ou j’utilise mes données mobiles, si possible.', 'Je me connecte au réseau qui a le meilleur signal, sans vérifier son nom.'], 'correct': 2, 'feedback': 'Les réseaux publics demandent de la prudence. Un VPN fiable peut protéger une partie des échanges, mais il ne bloque pas toutes les arnaques. N’accepte pas une alerte de sécurité sans comprendre sa cause.', 'skill': 'Réseaux publics'}, {'title': 'Installer sans réfléchir ?', 'prompt': 'Un camarade te propose un logiciel inconnu qui demande les droits administrateur sur un ordinateur du collège.', 'choices': ['Je demande au responsable et je privilégie les outils autorisés par l’établissement.', 'Je lui donne les identifiants administrateur.', 'Je l’installe pour voir, même sans autorisation.', 'Je désactive l’antivirus pour faciliter l’installation.'], 'correct': 0, 'feedback': 'Les droits administrateur permettent de modifier profondément un appareil. Ils ne doivent pas être partagés. Un compte utilisateur limite certains risques. Apps Éducation est un exemple de service institutionnel présenté dans la vidéo.', 'skill': 'Droits et outils autorisés'}, {'title': 'Un compte semble piraté', 'prompt': 'Des messages partent de ton compte sans que tu les aies écrits. Que fais-tu ?', 'choices': ['J’ignore le problème.', 'Je préviens un adulte ou le responsable, puis je sécurise le compte depuis un appareil de confiance.', 'Je paie une personne inconnue qui promet une réparation immédiate.', 'Je supprime les messages envoyés et je conserve le même mot de passe.'], 'correct': 1, 'feedback': 'Demande de l’aide rapidement. Depuis un appareil de confiance, change le mot de passe compromis et ceux qui le réutilisaient. Avec le responsable, vérifie les sessions, les protections et l’appareil. Cybermalveillance.gouv.fr propose des ressources publiques d’assistance.', 'skill': 'Réagir à un incident'}]

default cyber_score = 0
default cyber_index = 0
default cyber_missed = []
default cyber_order = []
default cyber_choice = 0


init -2 python:
    config.screen_width = 1280
    config.screen_height = 720

image cyber_background = im.Scale("images/background.png", 1280, 720)
default cyber_use_sfx = True
default cyber_use_music = True

init python:
    def cyber_sound(name):
        if cyber_use_sfx:
            renpy.sound.play("audio/" + name + ".ogg")
    def cyber_toggle_music():
        global cyber_use_music
        cyber_use_music = not cyber_use_music
        renpy.music.set_pause(not cyber_use_music)

screen cyber_controls():
    zorder 100
    frame:
        style "default"
        xpos 20
        ypos 12
        padding (12, 8)
        background Solid("#07162cdd")
        text ("Score : %d/10  |  Erreurs : %d  |  Étape : %d/10" % (cyber_score, len(cyber_missed), min(cyber_index + 1, 10))):
            style "default"
            size 18
            color "#ffffff"
    frame:
        style "default"
        xalign 0.98
        ypos 12
        padding (12, 8)
        background Solid("#07162cdd")
        hbox:
            spacing 18
            textbutton ("Effets : ON" if cyber_use_sfx else "Effets : OFF"):
                action ToggleVariable("cyber_use_sfx")
                text_size 18
                text_color "#ffffff"
                text_hover_color "#65e2d1"
            textbutton ("Musique : ON" if cyber_use_music else "Musique : OFF"):
                action Function(cyber_toggle_music)
                text_size 18
                text_color "#ffffff"
                text_hover_color "#65e2d1"

screen cyber_page(title, body, options, credits=None):
    modal True
    add "cyber_background"
    # Dimensions explicites : indépendantes des styles du projet hôte.
    frame:
        style "default"
        background Solid("#07162ccc")
        align (0.5, 0.5)
        xysize (int(config.screen_width * 0.84), int(config.screen_height * 0.80))
        padding (24, 20)
        viewport:
            style "default"
            xysize (int(config.screen_width * 0.84) - 48, int(config.screen_height * 0.80) - 40 - (130 if credits else 0))
            mousewheel True
            draggable True
            arrowkeys True
            pagekeys True
            vbox:
                style "default"
                spacing 16
                xsize int(config.screen_width * 0.84) - 48
                text title:
                    style "default"
                    size 30
                    color "#65e2d1"
                    xsize int(config.screen_width * 0.84) - 64
                    substitute False
                text body:
                    style "default"
                    size 23
                    color "#ffffff"
                    xsize int(config.screen_width * 0.84) - 64
                    substitute False
                for caption, value in options:
                    button:
                        style "default"
                        action Return(value)
                        xsize int(config.screen_width * 0.84) - 64
                        background Solid("#217d86")
                        hover_background Solid("#125d66")
                        padding (16, 14)
                        text caption:
                            style "default"
                            size 22
                            color "#ffffff"
                            xsize int(config.screen_width * 0.84) - 96
                            substitute False
                text "Si nécessaire, fais défiler avec la molette ou les flèches du clavier.":
                    style "default"
                    size 16
                    color "#c3d5e6"
                    xsize int(config.screen_width * 0.84) - 64


    if credits:
        frame:
            style "default"
            background Solid("#07162ccc")
            xpos int(config.screen_width * 0.08) + 24
            ypos int(config.screen_height * 0.90) - 130
            xysize (int(config.screen_width * 0.84) - 48, 110)
            padding (0, 8)
            text credits:
                style "default"
                size 16
                color "#c3d5e6"
                xsize int(config.screen_width * 0.84) - 64
                substitute False



label start:
    call cyber_mission
    return

label cyber_mission:
    window hide
    scene cyber_background
    $ cyber_score = 0
    $ cyber_index = 0
    $ cyber_missed = []
    $ renpy.music.play("audio/theme.ogg", loop=True, fadein=1.5)
    $ renpy.music.set_volume(0.30)
    $ renpy.music.set_pause(not cyber_use_music)
    show screen cyber_controls
    call screen cyber_page("MISSION CYBERSÉCURITÉ", 'Le club du collège prépare un projet numérique. Aide l’équipe à protéger ses comptes, ses appareils et ses fichiers !', [("Commencer la mission", "start")], credits='Inspiration : Réseau Canopé — « Améliorer la cybersécurité de ses outils numériques » (2023).\nSource : tube.reseau-canope.fr/w/2C9ZLEhnHfFLjpz82h8aTH\nSituations et code originaux : aide de ChatGPT (2026) • Licence proposée : CC BY-NC-SA 4.0.\nRen’Py : renpy.org • Décor et effets : projet fourni par l’enseignant. Musique originale : « Circuit nocturne », synthèse sonore (2026). Aucun média Canopé repris.')
    if _return == "exit":
        hide screen cyber_controls
        $ renpy.music.stop(fadeout=1.0)
        return

label cyber_round:
    $ cyber_score = 0
    $ cyber_index = 0
    $ cyber_missed = []
    while cyber_index < len(CYBER_QUESTIONS):
        $ cyber_sound("level")
        $ cyber_question = CYBER_QUESTIONS[cyber_index]
        $ cyber_order = list(enumerate(cyber_question["choices"]))
        $ renpy.random.shuffle(cyber_order)
        $ cyber_options = [(caption, original) for original, caption in cyber_order]
        $ cyber_heading = "Situation %d/%d — %s" % (cyber_index + 1, len(CYBER_QUESTIONS), cyber_question["title"])
        $ cyber_body = "Score : %d/%d\n\n%s" % (cyber_score, cyber_index, cyber_question["prompt"])
        call screen cyber_page(cyber_heading, cyber_body, cyber_options)
        $ cyber_choice = _return
        if cyber_choice == cyber_question["correct"]:
            $ cyber_score += 1
            $ cyber_sound("correct")
            $ cyber_result = "Bonne réponse !"
        else:
            $ cyber_missed.append(cyber_question["skill"])
            $ cyber_sound("error")
            $ cyber_result = "Un réflexe à améliorer"
        $ cyber_body = "Ton choix : " + cyber_question["choices"][cyber_choice] + "\n\nRéponse à retenir : " + cyber_question["choices"][cyber_question["correct"]] + "\n\n" + cyber_question["feedback"]
        call screen cyber_page(cyber_result, cyber_body, [("J’ai lu : continuer", None)])
        $ cyber_index += 1

    $ cyber_sound("victory")
    if cyber_score >= 8:
        $ cyber_message = "Tu as déjà de bons réflexes ! Continue à les appliquer et à demander de l’aide quand tu hésites."
    elif cyber_score >= 5:
        $ cyber_message = "Tu progresses. Relis les réflexes à revoir, puis retente la mission."
    else:
        $ cyber_message = "La mission t’a présenté plusieurs réflexes utiles. Tu peux rejouer pour t’entraîner."
    $ cyber_review = "\n\nÀ revoir : " + ", ".join(cyber_missed) if cyber_missed else "\n\nTu as réussi les 10 situations."
    $ cyber_body = cyber_message + cyber_review + "\n\nÀ discuter en classe :\n1. Quel réflexe vas-tu appliquer dès aujourd’hui ?\n2. Pourquoi HTTPS ne suffit-il pas à garantir qu’un site est honnête ?\n3. À qui demander de l’aide au collège ?"
    call screen cyber_page("Mission terminée — %d/10" % cyber_score, cyber_body, [("Rejouer (score remis à zéro)", "replay"), ("Revoir tous les conseils", "review"), ("Retour au menu", "exit")])
    if _return == "replay":
        jump cyber_round
    if _return == "review":
        $ cyber_body = "\n\n".join(q["skill"] + " : " + q["feedback"] for q in CYBER_QUESTIONS)
        call screen cyber_page("Les dix réflexes à retenir", cyber_body, [("Rejouer", "replay"), ("Retour au menu", "exit")])
        if _return == "replay":
            jump cyber_round
    hide screen cyber_controls
    $ renpy.music.stop(fadeout=1.0)
    return
